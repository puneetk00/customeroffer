# Magento 2 Special page for customer discount according to choose item each category.
Description : Magento 2.x Custom discount page for producuts. if user select one product then dicount 0 if customer select 2 product discount 5% if 3 then 10% if 4 then 15% if 5 then 20%. Single item quantity should be 1 and only added from http://yourdomain.com/offer page. 
